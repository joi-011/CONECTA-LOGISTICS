-- CONECTA MVP 1.0 | Supabase PostgreSQL
-- Ejecutar en un proyecto Supabase nuevo. Revisar políticas antes de producción.
create extension if not exists pgcrypto;

create type public.account_role as enum ('company','carrier','admin');
create type public.verification_status as enum ('pending','in_review','approved','rejected','expired');
create type public.load_status as enum ('draft','published','assigned','in_transit','delivered','cancelled','disputed');
create type public.document_type as enum ('identity','business_registration','driver_license','vehicle_registration','insurance','operating_permit','other');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  role public.account_role not null,
  full_name text not null,
  phone text,
  country_code char(2) not null default 'PA',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table public.companies (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null unique references public.profiles(id),
  legal_name text not null,
  trade_name text,
  tax_id text,
  email text,
  address text,
  verification public.verification_status not null default 'pending',
  created_at timestamptz not null default now()
);
create table public.carriers (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null unique references public.profiles(id),
  business_name text not null,
  tax_id text,
  email text,
  phone text,
  service_countries char(2)[] not null default array['PA']::char(2)[],
  verification public.verification_status not null default 'pending',
  rating numeric(3,2) not null default 0 check (rating between 0 and 5),
  created_at timestamptz not null default now()
);
create table public.vehicles (
  id uuid primary key default gen_random_uuid(),
  carrier_id uuid not null references public.carriers(id) on delete cascade,
  vehicle_type text not null,
  plate_number text not null,
  capacity_kg numeric(12,2),
  capacity_m3 numeric(12,2),
  refrigerated boolean not null default false,
  country_code char(2) not null default 'PA',
  verification public.verification_status not null default 'pending',
  active boolean not null default true,
  created_at timestamptz not null default now(),
  unique(country_code, plate_number)
);
create table public.documents (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id),
  vehicle_id uuid references public.vehicles(id) on delete cascade,
  document_type public.document_type not null,
  storage_path text not null,
  issuing_country char(2) not null default 'PA',
  expires_on date,
  status public.verification_status not null default 'pending',
  reviewed_by uuid references public.profiles(id),
  reviewed_at timestamptz,
  review_note text,
  created_at timestamptz not null default now()
);
create table public.loads (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id),
  reference_code text unique,
  origin_country char(2) not null default 'PA',
  origin_address text not null,
  destination_country char(2) not null default 'PA',
  destination_address text not null,
  cargo_description text not null,
  cargo_weight_kg numeric(12,2),
  cargo_volume_m3 numeric(12,2),
  vehicle_type text not null,
  pickup_at timestamptz,
  budget numeric(12,2),
  currency char(3) not null default 'USD',
  status public.load_status not null default 'draft',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table public.quotes (
  id uuid primary key default gen_random_uuid(),
  load_id uuid not null references public.loads(id) on delete cascade,
  carrier_id uuid not null references public.carriers(id),
  vehicle_id uuid references public.vehicles(id),
  amount numeric(12,2) not null check (amount > 0),
  currency char(3) not null default 'USD',
  message text,
  estimated_pickup timestamptz,
  estimated_delivery timestamptz,
  status text not null default 'submitted' check(status in ('submitted','accepted','rejected','withdrawn')),
  created_at timestamptz not null default now(),
  unique(load_id,carrier_id)
);
create table public.shipments (
  id uuid primary key default gen_random_uuid(),
  load_id uuid not null unique references public.loads(id),
  quote_id uuid not null unique references public.quotes(id),
  company_id uuid not null references public.companies(id),
  carrier_id uuid not null references public.carriers(id),
  agreed_amount numeric(12,2) not null,
  currency char(3) not null default 'USD',
  status public.load_status not null default 'assigned',
  pickup_code_hash text,
  delivery_code_hash text,
  created_at timestamptz not null default now()
);
create table public.tracking_events (
  id uuid primary key default gen_random_uuid(),
  shipment_id uuid not null references public.shipments(id) on delete cascade,
  actor_id uuid references public.profiles(id),
  event_type text not null,
  note text,
  latitude double precision,
  longitude double precision,
  created_at timestamptz not null default now()
);
create table public.delivery_proofs (
  id uuid primary key default gen_random_uuid(),
  shipment_id uuid not null references public.shipments(id) on delete cascade,
  uploaded_by uuid not null references public.profiles(id),
  storage_path text not null,
  recipient_name text,
  received_at timestamptz not null default now()
);
create table public.reviews (
  id uuid primary key default gen_random_uuid(),
  shipment_id uuid not null references public.shipments(id),
  reviewer_id uuid not null references public.profiles(id),
  reviewee_id uuid not null references public.profiles(id),
  score int not null check(score between 1 and 5),
  comment text,
  created_at timestamptz not null default now(),
  unique(shipment_id,reviewer_id)
);
create table public.disputes (
  id uuid primary key default gen_random_uuid(),
  shipment_id uuid not null references public.shipments(id),
  opened_by uuid not null references public.profiles(id),
  reason text not null,
  description text,
  status text not null default 'open' check(status in ('open','investigating','resolved','rejected')),
  resolution text,
  created_at timestamptz not null default now()
);

create index loads_status_pickup_idx on public.loads(status,pickup_at);
create index loads_route_idx on public.loads(origin_country,destination_country);
create index quotes_load_idx on public.quotes(load_id,status);
create index tracking_shipment_idx on public.tracking_events(shipment_id,created_at desc);
create index documents_owner_idx on public.documents(owner_id,status);

-- Seguridad base: activar RLS en todas las tablas con datos privados.
alter table public.profiles enable row level security;
alter table public.companies enable row level security;
alter table public.carriers enable row level security;
alter table public.vehicles enable row level security;
alter table public.documents enable row level security;
alter table public.loads enable row level security;
alter table public.quotes enable row level security;
alter table public.shipments enable row level security;
alter table public.tracking_events enable row level security;
alter table public.delivery_proofs enable row level security;
alter table public.reviews enable row level security;
alter table public.disputes enable row level security;

-- Políticas iniciales de mínimo privilegio.
create policy "profile read own" on public.profiles for select using (id = auth.uid());
create policy "profile update own" on public.profiles for update using (id = auth.uid()) with check (id = auth.uid());
create policy "company owner read" on public.companies for select using (owner_id = auth.uid());
create policy "company owner insert" on public.companies for insert with check (owner_id = auth.uid());
create policy "carrier owner read" on public.carriers for select using (owner_id = auth.uid());
create policy "carrier owner insert" on public.carriers for insert with check (owner_id = auth.uid());
create policy "vehicle owner access" on public.vehicles for all using (
  exists(select 1 from public.carriers c where c.id=carrier_id and c.owner_id=auth.uid())
) with check (
  exists(select 1 from public.carriers c where c.id=carrier_id and c.owner_id=auth.uid())
);
create policy "documents owner access" on public.documents for all using (owner_id=auth.uid()) with check (owner_id=auth.uid());
create policy "company manages own loads" on public.loads for all using (
  exists(select 1 from public.companies c where c.id=company_id and c.owner_id=auth.uid())
) with check (
  exists(select 1 from public.companies c where c.id=company_id and c.owner_id=auth.uid())
);
-- Las lecturas de cargas publicadas para transportistas y las cotizaciones/operaciones
-- deben implementarse mediante funciones RPC o políticas revisadas que validen
-- pertenencia y estado. No abrir tablas privadas con USING(true).
