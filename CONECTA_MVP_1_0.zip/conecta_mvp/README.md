# CONECTA Logistics — MVP 1.0

## Contenido
- `web/index.html`: prototipo navegable en español. Permite cambiar entre Empresa, Transportista y Administración; publicar cargas, cotizar, aceptar ofertas y avanzar estados. Los datos de demo se guardan en `localStorage`.
- `supabase/schema.sql`: esquema inicial PostgreSQL para Supabase.
- `mobile/README.md`: ruta recomendada para compilar Android/iOS con Flutter.

## Probar el prototipo
Abre `web/index.html` en un navegador moderno. No requiere instalación ni cuenta. Usa "Reiniciar demo" para restaurar los datos de ejemplo.

## Importante: límites de esta demo
No es todavía un servicio de producción: no autentica usuarios reales, no sube documentos, no verifica identidad, no rastrea GPS, no procesa pagos, no envía notificaciones ni protege datos entre dispositivos. No uses datos personales reales en esta demo.

## Backend
1. Crear un proyecto en Supabase.
2. Ejecutar `supabase/schema.sql` en el SQL Editor.
3. Configurar autenticación por correo/teléfono y verificación MFA para administradores.
4. Crear buckets privados para documentos y pruebas de entrega.
5. Completar políticas RLS para cargas públicas, cotizaciones, operaciones, seguimiento y reclamaciones.
6. Implementar funciones RPC transaccionales para aceptar cotización y cambiar estados; impedir que un usuario acepte una oferta de una carga ajena.
7. Configurar auditoría, backups, alertas y reglas de retención de documentos.

No colocar nunca la `service_role key` en una app móvil o navegador. Solo usar claves públicas anon/publishable con RLS.

## Reglas de negocio recomendadas
- Solo empresas aprobadas pueden publicar cargas.
- Solo transportistas aprobados y con vehículo/documentos vigentes pueden cotizar.
- Aceptar una oferta debe ser atómico: una sola cotización aceptada por carga.
- Pago directo entre las partes: CONECTA registra el importe acordado y el estado, pero no custodia dinero ni garantiza el pago.
- Para cargas internacionales: validar permisos, aduanas, seguros, responsabilidades, restricciones de mercancías y requisitos de cada país.
- La insignia "Verificado" solo se concede después de revisión real y trazable.

## Antes de lanzar
Revisión legal y contractual en Panamá, términos de uso, privacidad, tratamiento de datos, seguros y responsabilidad del intermediario; pruebas de seguridad; pruebas de restauración; y piloto cerrado con empresas y transportistas.
