# Aplicación Android e iOS

La ruta recomendada para compartir código entre Android y iPhone es Flutter.

## Crear proyecto
```bash
flutter create conecta_mobile
cd conecta_mobile
flutter pub add supabase_flutter go_router flutter_riverpod
```

## Módulos a implementar
1. Autenticación y selección de rol.
2. Registro de empresa / transportista.
3. Carga segura de documentos.
4. Gestión de vehículos.
5. Tablero de cargas y filtros.
6. Cotizaciones y aceptación transaccional.
7. Seguimiento y prueba de entrega.
8. Calificaciones y reclamaciones.
9. Panel administrativo web separado.

## Configuración
Conectar Flutter a Supabase con URL del proyecto y clave pública. Activar RLS antes de conectar clientes. No incluir secretos de servidor en la aplicación.

Este paquete incluye el esquema de datos y el prototipo web demostrativo; la app Flutter nativa y las integraciones de producción son la siguiente fase de implementación.
